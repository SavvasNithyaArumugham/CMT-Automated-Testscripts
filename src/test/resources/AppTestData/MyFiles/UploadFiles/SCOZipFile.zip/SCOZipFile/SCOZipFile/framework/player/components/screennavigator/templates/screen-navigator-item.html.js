define('text!components/screennavigator/templates/screen-navigator-item.html',[],function () { return '<!-- style for this div is in skin1.css -->\n<div>{{ screenLabel }}</div>';});
