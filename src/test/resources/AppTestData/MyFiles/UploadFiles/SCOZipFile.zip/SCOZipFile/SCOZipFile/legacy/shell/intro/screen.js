/*jslint nomen: true*/
/*globals Backbone,_,console,$, class */

define(['player/screen/screen-helper'], function(ScreenHelper) {'use strict';
	var Helper, mySelf;

	Helper = ScreenHelper.extend({

	});

	Helper.prototype.init = function() {
		mySelf = this;
		// add functionality to show/hide play button for video player
		if($('html').hasClass('desktop')){
			$("#mActivity .video-play-button").hide();
		}else{
			$("#mActivity .video-play-button").show();
		}
	};

	Helper.prototype.fadeOut = function() {
		mySelf.comp_video.$el.fadeOut( 500 , function(){
			mySelf.objActivity.launchNextActivity();
		});
		
	};

	Helper.prototype.destroy = function() {

	};

	return Helper;
});
