define('text!components/dnd/dnd.html',[],function () { return '<div id="dndHolder">\n</div>\n';});
