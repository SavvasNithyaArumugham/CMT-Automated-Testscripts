define('text!components/togglebutton/template/toggle-button.html',[],function () { return '<label class="toggleButtontnLabel"> {{ label }} </label>';});
