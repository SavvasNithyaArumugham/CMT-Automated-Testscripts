define('text!components/physicsengine/template/physics-engine.html',[],function () { return '<canvas id="{{ canId }}" width="{{ canWidth }}" height="{{ canHeight }}" >\n\n</canvas>\n';});
