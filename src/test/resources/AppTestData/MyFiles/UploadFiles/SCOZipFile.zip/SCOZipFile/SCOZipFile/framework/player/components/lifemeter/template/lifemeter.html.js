define('text!components/lifemeter/template/lifemeter.html',[],function () { return '';});
