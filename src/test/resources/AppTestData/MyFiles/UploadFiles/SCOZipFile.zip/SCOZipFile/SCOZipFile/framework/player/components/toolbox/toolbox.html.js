define('text!player/components/toolbox/toolbox.html',[],function () { return '<div id="toolboxContainer">\n\t<div id="toolboxHeader" class="toolboxHeader">Tool Box</div>\n</div>\n';});
