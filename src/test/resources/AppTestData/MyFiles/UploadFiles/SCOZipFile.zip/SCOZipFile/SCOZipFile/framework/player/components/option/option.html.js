define('text!components/option/option.html',[],function () { return '<div id="optionHolder">\n\t<div id="optionLabel">{{ label }}</div>\n\t<div id="optionImage"></div>\n</div>';});
