define('text!components/calculator/template/calculator-item.html',[],function () { return '';});
