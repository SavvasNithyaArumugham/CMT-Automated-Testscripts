define('text!components/carousel/template/carousel-item.html',[],function () { return '';});
