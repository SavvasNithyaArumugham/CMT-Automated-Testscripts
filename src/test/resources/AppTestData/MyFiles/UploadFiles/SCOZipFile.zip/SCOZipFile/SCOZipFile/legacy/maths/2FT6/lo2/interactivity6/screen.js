/*jslint nomen: true*/
/*globals Backbone,_,////console,$, class */

define(['player/screen/screen-helper'], function(ScreenHelper) {
	'use strict';
	var Helper, mySelf, customData = "legacy/maths/2FT1/lo1/assets/audio/audio";
	var device_used;
	var video_playing;
	var boxes = [];
	var INTERVAL = 2;
	var ctx;
	var c,notDragged;
	var center = {
		x : 220,
		y : 205
	};
	var vertices = [];
	var vertices_area = 5;
	var half = 5;
	var isDrag = false;
	var isResizeDrag = false;
	var expectResize = -1;
	var mx, my;
	var mySel = null;
	var mySelColor = '#CC0000';
	var mySelWidth = 2;
	var radius = 150;
	var previousAngle = [], currentAngle = [], startAngle = [], endAngle = [];
	var stylePaddingLeft, stylePaddingTop, styleBorderLeft, styleBorderTop;
	Helper = ScreenHelper.extend({

	});

	Helper.prototype.init = function() {
		mySelf = this;
		$("#btnReplay").off("click").on("click", function() {
			mySelf.objActivity.jumpToActivityByID(3);
		});
		
		$("#btnHome").on("click",function(){
			mySelf.objActivity.model.set("hotspot_click", 0);
		});
		
		notDragged = true;
		$(".contentbox").animate({
			'right' : '10px'
		}, 1000);
		vertices[0] = {
			x : (+center.x) + radius,
			y : center.y
		};
		vertices[1] = {
			x : center.x + (Math.cos(-1) * radius),
			y : center.y + (Math.sin(-1) * radius)
		};
		vertices[2] = {
			x : vertices[1].x,
			y : vertices[1].y
		};
		vertices[3] = {
			x : center.x - (vertices[2].x - center.x),
			y : vertices[2].y
		};
		vertices[4] = {
			x : vertices[3].x,
			y : center.y + (center.y - vertices[3].y)
		};
		vertices[5] = {
			x : (vertices[2].x),
			y : vertices[4].y
		};
		//console.log(vertices);
		$("#btnInstruction").removeClass("liBtnInstruction_selected").addClass("liBtnInstruction");
		$("#btnInstruction").attr("isselected", "false");
		
		$("#screenHolder").removeClass("screenHolderH").addClass("screenHolderI");

		mySelf.drawAngle();

		$(".hotspot").off("click").on("click", function() {
			$(".hotspot").animate({
				'left' : '300px'
			}, 700, function() {
				$("#sprite_cont").show();
				mySelf.sprite_1.play(false, 1, 13);
			});
		});
		$(".closer").off("click").on("click", function() {
			$(this).parent().parent().hide();
		});
		$(".btn").off("click").on("click", function() {
			var id = this.id.split("_")[1];
			switch(id) {
			case "1":mySelf.objActivity.model.set("hotspot_click",1);
					 mySelf.objActivity.jumpToActivityByID(3);
				break;
			case "2":mySelf.objActivity.model.set("hotspot_click",2);
			mySelf.objActivity.jumpToActivityByID(3);
				break;
			case "3":
			mySelf.objActivity.jumpToActivityByID(4);
				break;
			}
		});
	};

	
	Helper.prototype.drawAngle = function() {
		c = document.getElementById("main_canvas");
		ctx = c.getContext("2d");
		draw();
		c.onmousedown = myDown;
		c.onmouseup = myUp;
		c.onmousemove = myMove;
		c.addEventListener('touchend', myUp, false);
		c.addEventListener('touchstart', myDown1, false);
		c.addEventListener('touchmove', myMove, false);
		//$('body').bind( "touchstart",myDown);
		//$('body').bind( "touchend",myUp);
		if (document.defaultView && document.defaultView.getComputedStyle) {
			stylePaddingLeft = parseInt(document.defaultView.getComputedStyle(c, null)['paddingLeft'], 10) || 0;
			stylePaddingTop = parseInt(document.defaultView.getComputedStyle(c, null)['paddingTop'], 10) || 0;
			styleBorderLeft = parseInt(document.defaultView.getComputedStyle(c, null)['borderLeftWidth'], 10) || 0;
			styleBorderTop = parseInt(document.defaultView.getComputedStyle(c, null)['borderTopWidth'], 10) || 0;
		}

		function clear(c) {
			c.clearRect(0, 0, 740, 510);
		}

		function invalidate() {
			canvasValid = false;
		}

		function draw() {
			var half = 5;
			clear(ctx);
			ctx.stroke();
			ctx.beginPath();
			ctx.fillStyle = "transparent";
			ctx.fillRect(0, 0, 740, 510);
			if($('html').hasClass('desktop'))
			ctx.setLineDash([0]);
			ctx.arc(center.x, center.y, radius, 0, 2 * Math.PI);
			ctx.strokeStyle = "#fcca53";
			ctx.fillStyle = "#fff9ea";
			ctx.lineWidth = "3";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			ctx.moveTo(center.x, center.y);
			ctx.lineTo(vertices[1].x, vertices[1].y);
			ctx.lineWidth = "3";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = "1";
			ctx.strokeStyle = "#FF0000";
			ctx.fillStyle = "#FF0000";
			ctx.arc(vertices[1].x, vertices[1].y, 10, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();
			vertices[2] = {
				x : vertices[1].x,
				y : vertices[1].y
			};
			vertices[3] = {
				x : center.x - (vertices[2].x - center.x),
				y : vertices[2].y
			};
			vertices[4] = {
				x : vertices[3].x,
				y : center.y + (center.y - vertices[3].y)
			};
			vertices[5] = {
				x : (vertices[2].x),
				y : vertices[4].y
			};
			ctx.beginPath();
			ctx.fillStyle = "#000000";
			ctx.strokeStyle = "#000000";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([7]);
			ctx.moveTo(vertices[2].x, vertices[2].y);
			ctx.lineTo(vertices[5].x, vertices[5].y);
			ctx.moveTo(vertices[3].x, vertices[3].y);
			ctx.lineTo(center.x, center.y);
			ctx.moveTo(vertices[4].x, vertices[4].y);
			ctx.lineTo(center.x, center.y);
			ctx.moveTo(vertices[5].x, vertices[5].y);
			ctx.lineTo(center.x, center.y);
			ctx.moveTo(vertices[4].x, vertices[4].y);
			ctx.lineTo(vertices[3].x, vertices[3].y);
			
			ctx.lineWidth = "1.5";
			ctx.stroke();
			//ctx.closePath();
			ctx.beginPath();
			var endAngle = find_angle(vertices[1], center, vertices[0]);
			var angle = endAngle;
			ctx.fillStyle = "#000000";
			ctx.font = 'bold 20px Calibri';
			ctx.fillText(Math.round(endAngle), center.x+20, center.y-20);
			ctx.font = 'bold 15px Calibri';
			ctx.fillText("o", center.x + 40, center.y - 35);
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#000000";
			ctx.font = 'bold 20px Calibri';
			ctx.fillText(Math.round(180-endAngle), center.x-50, center.y-20);
			ctx.font = 'bold 15px Calibri';
			ctx.fillText("o", center.x - 20, center.y - 35);
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#000000";
			ctx.font = 'bold 20px Calibri';
			ctx.fillText(Math.round(180+endAngle), center.x-50, center.y+30);
			ctx.font = 'bold 15px Calibri';
			ctx.fillText("o", center.x - 20, center.y + 15);
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#000000";
			ctx.font = 'bold 20px Calibri';
			ctx.fillText(Math.round(360-endAngle), center.x+20, center.y+30);
			ctx.font = 'bold 15px Calibri';
			ctx.fillText("o", center.x + 50, center.y + 15);
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = "1";
			ctx.strokeStyle = "#000000";
			ctx.fillStyle = "#000000";
			ctx.arc(vertices[3].x, vertices[3].y, 5, 0, 2 * Math.PI);
			if($('html').hasClass('desktop'))
			ctx.setLineDash([0]);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = "1";
			ctx.strokeStyle = "#000000";
			ctx.fillStyle = "#000000";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([0]);
			ctx.arc(vertices[4].x, vertices[4].y, 5, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = "1";
			ctx.strokeStyle = "#000000";
			ctx.fillStyle = "#000000";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([0]);
			ctx.arc(vertices[5].x, vertices[5].y, 5, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = "1";
			ctx.strokeStyle = "#FF0000";
			ctx.fillStyle = "#FF0000";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([0]);
			ctx.arc(vertices[2].x, vertices[2].y, 10, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			
			if (Math.round(endAngle) == 0 || notDragged) {
				//ctx.arc(center.x, center.y, 50, 0, 0, false);
			} else {
				endAngle = (Math.PI / 180 ) * (360 - endAngle);
				ctx.arc(center.x, center.y, 30, 0, endAngle, true);
				if($('html').hasClass('desktop'))
				ctx.setLineDash([2]);
			}

			ctx.lineWidth = "2";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([2]);
			if (Math.round(endAngle) == 0 || notDragged) {

			} else {
				ctx.arc(center.x, center.y, 50, 0, ((Math.PI) + convertToRadian(angle)), true);
			}
			console.log(endAngle, (Math.PI / 2) + endAngle);
			ctx.lineWidth = "2.5";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([2]);
			if (Math.round(endAngle) == 0 || notDragged) {

			} else {
				ctx.arc(center.x, center.y, 70, 0, ((Math.PI) - convertToRadian(angle)), true);
			}
			console.log(endAngle, (Math.PI / 2) + endAngle);
			ctx.lineWidth = "3";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			if($('html').hasClass('desktop'))
			ctx.setLineDash([2]);
			if (Math.round(endAngle) == 0 || notDragged) {

			} else {
				ctx.arc(center.x, center.y, 90, 0, ((2*Math.PI) + convertToRadian(angle)), true);
			}
			console.log(endAngle, (Math.PI / 2) + endAngle);
			ctx.lineWidth = "3.5";
			ctx.stroke();
			//ctx.closePath();
		}

		function convertToRadian(angle) {
			return (Math.PI / 180 ) * (angle);
		}

		function find_angle(A, B, C) {
			var AB = Math.sqrt(Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2));
			var BC = Math.sqrt(Math.pow(B.x - C.x, 2) + Math.pow(B.y - C.y, 2));
			var AC = Math.sqrt(Math.pow(C.x - A.x, 2) + Math.pow(C.y - A.y, 2));
			var calcAngel = Math.acos((BC * BC + AB * AB - AC * AC) / (2 * BC * AB)) * (180 / Math.PI);
			if (A.y > C.y) {
				return 180 + (180 - calcAngel);
			}
			return calcAngel;

		}

		function calcAngle(x1, x2, y1, y2) {
			var calcAngle = Math.atan2(y2 - y1, x2 - x1);
			return calcAngle;
		}

		function myMove(e) {
			draw();
			if (isResizeDrag) {
					
				if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
					getMouse1(e);
				} else {
					getMouse(e);
				}
				if(mx < center.x || my > center.y){
					return;
				}
				var angleMade = calcAngle(center.x, mx, center.y, my);
				switch (expectResize) {
				case 0:
				notDragged = false;
					vertices[1].x = center.x + (Math.cos(angleMade) * radius);
					vertices[1].y = center.y + (Math.sin(angleMade) * radius);
					break;

				}
				return;
			}

			if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
				getMouse1(e);
			} else {
				getMouse(e);
			}
			// if there's a selection see if we grabbed one of the selection handles
			if ((mx <= vertices[1].x + half && mx >= vertices[1].x - half) && (my <= vertices[1].y + half && my >= vertices[1].y - half))
				expectResize = 0;
			else
				expectResize = 4;
			switch (expectResize) {
			case 0:
				this.style.cursor = 'pointer';
				//this.style.pointerEvents = "auto";
				break;
			case 1:
				this.style.cursor = 'pointer';
				//this.style.pointerEvents = "none";
				break;
			case 2:
				this.style.cursor = 'pointer';
				//this.style.pointerEvents = "none";
				break;
			default:
				this.style.cursor = 'default';
			}
			return;
		}

		// Happens when the mouse is clicked in the canvas
		function myDown(e) {
			getMouse(e);
			if (expectResize !== -1) {
				this.style.cursor = 'none';
				isResizeDrag = true;
				return;
			}
		}

		function myDown1(e) {
			
			e.preventDefault();
			getMouse1(e);
			if (expectResize !== -1) {
				this.style.cursor = 'none';
				isResizeDrag = true;
				return;
			}
		}

		function myUp(e) {
			//this.style.cursor = 'default';
			isDrag = false;
			isResizeDrag = false;
			expectResize = -1;
		}

		function getMouse(e) {
			
			var element = c, offsetX = 0, offsetY = 0;
			if (element.offsetParent) {
				do {
					offsetX += element.offsetLeft;
					offsetY += element.offsetTop;
				} while ((element = element.offsetParent));
			}

			// Add padding and border style widths to offset
			offsetX += stylePaddingLeft;
			offsetY += stylePaddingTop;

			offsetX += styleBorderLeft;
			offsetY += styleBorderTop;

			if (e.pageX - offsetX > 10 && e.pageY - offsetY > 10 && e.pageX - offsetX < 700 && e.pageY - offsetY < 450) {
				mx = e.pageX - offsetX;
				my = e.pageY - offsetY;
			} else {
				myUp(e);
			}

		}

		function getMouse1(e) {
			
			e.preventDefault();
			var element = c, offsetX = 0, offsetY = 0;
			if (element.offsetParent) {
				do {
					offsetX += element.offsetLeft;
					offsetY += element.offsetTop;
				} while ((element = element.offsetParent));
			}

			// Add padding and border style widths to offset
			offsetX += stylePaddingLeft;
			offsetY += stylePaddingTop;

			offsetX += styleBorderLeft;
			offsetY += styleBorderTop;
			if (e.touches[0].pageX - offsetX > 10 && e.touches[0].pageY - offsetY > 10 && e.touches[0].pageX - offsetX < 700 && e.touches[0].pageY - offsetY < 450) {
				mx = e.touches[0].pageX - offsetX;
				my = e.touches[0].pageY - offsetY;
				
			}
			if ((mx <= vertices[1].x + 20 && mx >= vertices[1].x - 20) && (my <= vertices[1].y + 20 && my >= vertices[1].y - 20)) {
				expectResize = 0;
				isResizeDrag = true;
			}
		}

	};

	Helper.prototype.destroy = function() {
		mySelf.objActivity.stopAudio("bgSound");
	};

	return Helper;
});
