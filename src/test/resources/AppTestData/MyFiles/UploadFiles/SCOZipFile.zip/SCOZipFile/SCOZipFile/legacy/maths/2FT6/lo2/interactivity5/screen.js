/*jslint nomen: true*/
/*globals Backbone,_,////console,$, class */

define(['player/screen/screen-helper'], function(ScreenHelper) {
	'use strict';
	var Helper, mySelf, customData = "legacy/maths/2FT1/lo1/assets/audio/audio";
	var device_used;
	var video_playing;
	var boxes = [];
	var INTERVAL = 2;
	var ctx;
	var c;
	var center = {
		x : 220,
		y : 205
	};
	var vertices = [];
	var vertices_area = 5;
	var half = 5;
	var isDrag = false;
	var isResizeDrag = false;
	var expectResize = -1;
	var mx, my;
	var mySel = null;
	var mySelColor = '#CC0000';
	var mySelWidth = 2;
	var radius = 150;
	var previousAngle = [], currentAngle = [], startAngle = [], endAngle = [];
	var stylePaddingLeft, stylePaddingTop, styleBorderLeft, styleBorderTop;
	Helper = ScreenHelper.extend({

	});

	Helper.prototype.init = function() {
		mySelf = this;
		$("#btnReplay").off("click").on("click", function() {
			mySelf.objActivity.jumpToActivityByID(3);
		});

		$("#btnHome").on("click",function(){
			mySelf.objActivity.model.set("hotspot_click", 0);
		});

		var caseValue = mySelf.objActivity.model.get("hotspot_click");
		switch(caseValue) {
		case 1:
			$("#popup_cont").show();
			$("#popup1").hide();
			$("#popup2").hide();
			$(".imageBtnHolder").css("background-image", "url(legacy/maths/2FT6/lo2/assets/images/2.png)");
			$("#popup1").show();
			break;
		case 2:
			$("#popup_cont").show();
			$("#popup1").hide();
			$("#popup2").hide();
			$(".imageBtnHolder").css("background-image", "url(legacy/maths/2FT6/lo2/assets/images/1.png)");
			$("#popup2").show();
			break;
		case 3:
			mySelf.objActivity.jumpToActivityByID(4);
			break;
		}

		$(".contentbox").animate({
			'right' : '10px'
		}, 1000);
		vertices[0] = {
			x : (+center.x) + radius,
			y : center.y
		};
		vertices[1] = {
			x : (+center.x) + radius,
			y : center.y
		};
		vertices[2] = {
			x : (vertices[1].x),
			y : center.y
		};
		//console.log(vertices);
		$("#btnInstruction").removeClass("liBtnInstruction_selected").addClass("liBtnInstruction");
		$("#btnInstruction").attr("isselected", "false");
		var source = [{
			"path" : customData + ".mp3",
			"type" : "mp3"
		}, {
			"path" : customData + ".ogg",
			"type" : "ogg"
		}];
		mySelf.objActivity.broadcastEventReceiver("shellCommonEvent", this, "manageShellCommonEvent");
		mySelf.objActivity.broadcastEventReceiver("headerGlobalEvent", mySelf, "handleBroadcastedEvent");
		$("#screenHolder").removeClass("screenHolderH").addClass("screenHolderI");
		mySelf.objActivity.broadcastEvent("updateModelValue", {
			value : 4
		});
		var loop = true;
		var comp = undefined;

		mySelf.playPopupAudio(customData, comp, loop);
		mySelf.objActivity.playAudio(source, false, "bgSound", true);
		mySelf.drawAngle();

		$(".hotspot").off("click").on("click", function() {
			$(".hotspot").animate({
				'left' : '300px'
			}, 700, function() {
				$("#sprite_cont").show();
				mySelf.sprite_1.play(false, 1, 13);
			});
		});
		$(".closer").off("click").on("click", function() {
			$(this).parent().parent().hide();
		});

		$(".btn").off("click").on("click", function() {
			var id = this.id.split("_")[1];
			$("#popup_cont").show();
			$("#popup1").hide();
			$("#popup2").hide();
			switch(id) {
			case "1":
					$(".imageBtnHolder").css("background-image","url(legacy/maths/2FT6/lo2/assets/images/2.png)");
					$("#popup1").show();
				break;
			case "2":$(".imageBtnHolder").css("background-image","url(legacy/maths/2FT6/lo2/assets/images/1.png)");
					$("#popup2").show();
				break;
			case "3":mySelf.objActivity.jumpToActivityByID(4);
				break;
			}
		});

	};

	Helper.prototype.onAnimFinish = function() {
		$(".videoPlayerContainerDiv2").show();
		$(".controllerDiv2").show();
		mySelf.comp_video.play();
	};

	Helper.prototype.hide_first_frame = function() {
		$(".first_frame_screen2").css("display", "none");
		if (device_used == "tablet") {
			$(".refreshButton2").css("left", "45px");
			$(".refreshButton2").show();
			$(".btnCaption").css("left", "90px");
			$(".closeCaptionDivStyle").css("left", "135px");
		}
		if (video_playing == false) {
			mySelf.comp_video.setTime(0);
			mySelf.comp_video.play();
		}
		video_playing = true;
	};

	Helper.prototype.showVolumeBtn = function() {

		if (device.mobile() === true || device.tablet() === true) {
			this.objScreen.btnVolume.hide();
		} else {
			this.objScreen.btnVolume.show();
		}
	};

	Helper.prototype.time_to_current_sprite = function() {
		video_playing = false;
	};

	Helper.prototype.showHideVolumeBar = function(e) {
		$("#volumeBar").toggle();
	};

	Helper.prototype.manageShellCommonEvent = function(objEvent) {
		var strTaskName = objEvent.data.taskName;
		switch(strTaskName) {
		case "onCreditPopupOpen":
			mySelf.comp_video.pause();
			mySelf.btnPlay.show();
			mySelf.btnPause.hide();
			break;
		}
	};

	Helper.prototype.volumeChange = function(e) {
		var currentPosition, duration, result;
		currentPosition = e.customData;
		result = currentPosition / 100;
		mySelf.comp_video.changeVolume(result);
	};

	Helper.prototype.showHideCaption = function(evt) {

		mySelf.caption.$el.toggle();
	};

	Helper.prototype.way_to_interactivity = function() {
		mySelf.comp_video.setTime(0);
		mySelf.comp_video.play();
	};

	Helper.prototype.handleBroadcastedEvent = function(objEvent) {

		switch(objEvent.data.taskName) {

		case "back":

			mySelf.objActivity.stopAudio("bgSound");
			mySelf.objActivity.jumpToActivityByID(4);
			break;
		}
	};

	Helper.prototype.playPopupAudio = function(src, comp, loop, onAudioFinish) {
		var objData = {};
		objData.taskName = "playAudio";
		objData.audiofile = src;
		objData.loop = true;
		mySelf.objActivity.broadcastEvent("manageShellLevelGlobalEvent", objData);
	};

	Helper.prototype.onAudioFinish = function() {
		var loop = true;
		//console.log("a");
		var comp = undefined;
		mySelf.playPopupAudio(customData, comp, loop);
	};

	Helper.prototype.stopPopupAudio = function() {
		var objData = {};
		objData.taskName = "stopAudio";
		mySelf.objActivity.broadcastEvent("manageShellLevelGlobalEvent", objData);
	};

	Helper.prototype.drawAngle = function() {
		c = document.getElementById("main_canvas");
		ctx = c.getContext("2d");

		setInterval(draw, INTERVAL);
		c.onmousedown = myDown;
		c.onmouseup = myUp;
		c.onmousemove = myMove;
		c.addEventListener('touchend', myUp, false);
		c.addEventListener('touchstart', myDown1, false);
		c.addEventListener('touchmove', myMove, false);
		//$('body').bind( "touchstart",myDown);
		//$('body').bind( "touchend",myUp);
		if (document.defaultView && document.defaultView.getComputedStyle) {
			stylePaddingLeft = parseInt(document.defaultView.getComputedStyle(c, null)['paddingLeft'], 10) || 0;
			stylePaddingTop = parseInt(document.defaultView.getComputedStyle(c, null)['paddingTop'], 10) || 0;
			styleBorderLeft = parseInt(document.defaultView.getComputedStyle(c, null)['borderLeftWidth'], 10) || 0;
			styleBorderTop = parseInt(document.defaultView.getComputedStyle(c, null)['borderTopWidth'], 10) || 0;
		}

		function clear(c) {
			c.clearRect(0, 0, 740, 510);
		}

		function invalidate() {
			canvasValid = false;
		}

		function draw() {
			var half = 5;
			clear(ctx);
			ctx.stroke();
			ctx.beginPath();
			ctx.fillStyle = "transparent";

			ctx.fillRect(0, 0, 740, 510);
			ctx.arc(center.x, center.y, radius, 0, 2 * Math.PI);
			ctx.strokeStyle = "#fcca53";
			ctx.fillStyle = "#fff9ea";
			ctx.lineWidth = "3";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			ctx.moveTo(center.x, center.y);
			ctx.lineTo(vertices[1].x, vertices[1].y);
			ctx.lineWidth = "3";
			ctx.stroke();
			ctx.closePath();
			vertices[2] = {
			x : (vertices[1].x),
			y : center.y
			};
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			ctx.moveTo(vertices[2].x, vertices[2].y);
			ctx.lineTo(vertices[1].x, vertices[1].y);
			ctx.lineWidth = "3";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.lineWidth = "1";
			ctx.strokeStyle = "#FF0000";
			ctx.fillStyle = "#FF0000";
			ctx.arc(vertices[1].x, vertices[1].y, 10, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();

			ctx.beginPath();

			ctx.lineWidth = "1";
			ctx.strokeStyle = "#FF0000";
			ctx.fillStyle = "#FF0000";
			ctx.arc(vertices[2].x, vertices[2].y, 5, 0, 2 * Math.PI);
			ctx.fill();
			ctx.stroke();
			ctx.closePath();

			ctx.beginPath();
			var endAngle = find_angle(vertices[1], center, vertices[0]);
			var angle = endAngle;
			console.log(angle, Math.sin(angle));
			ctx.fillStyle = "#000000";
			ctx.font = 'bold 20px Calibri';
			if(Math.round(endAngle) < 10){
				ctx.fillText(Math.round(endAngle), 290, 180);
			}else if(Math.round(endAngle) < 100){
				ctx.fillText(Math.round(endAngle), 280, 180);
			}else if(Math.round(endAngle) > 10){
				ctx.fillText(Math.round(endAngle), 270, 180);
			}
			ctx.font = 'bold 15px Calibri';
			ctx.fillText("o", 300, 170);
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#0066FF";
			ctx.strokeStyle = "#0066FF";
			if (Math.round(endAngle) == 0) {
				//ctx.arc(center.x, center.y, 50, 0, 0, false);
			} else {
				endAngle = (Math.PI / 180 ) * (360 - endAngle);
				ctx.arc(center.x, center.y, 50, 0, endAngle, true);
			}

			ctx.lineWidth = "1";
			ctx.stroke();
			ctx.closePath();
			ctx.beginPath();
			ctx.fillStyle = "#000000";
			ctx.font = 'bold 20px Calibri';
			var angleRequired=angle;
			angle = convertToRadian(Math.round(angle));;

			// if( angleRequired > 90 && angleRequired < 270){
			// ctx.fillText(Math.round((Math.cos(angle) * 1000)) / 1000, (center.x ), (center.y + vertices[1].y) / 2);
			// }else{
			// ctx.fillText(Math.round((Math.cos(angle) * 1000)) / 1000, (center.x - 55), (center.y + vertices[1].y) / 2);
			// }
			ctx.fillText(Math.round((Math.cos(angle) * 1000)) / 1000, (vertices[1].x-25), (center.y + 20 ));
		}

		function convertToRadian(angle) {
			return (Math.PI / 180 ) * (angle);
		}

		function find_angle(A, B, C) {
			var AB = Math.sqrt(Math.pow(B.x - A.x, 2) + Math.pow(B.y - A.y, 2));
			var BC = Math.sqrt(Math.pow(B.x - C.x, 2) + Math.pow(B.y - C.y, 2));
			var AC = Math.sqrt(Math.pow(C.x - A.x, 2) + Math.pow(C.y - A.y, 2));
			var calcAngel = Math.acos((BC * BC + AB * AB - AC * AC) / (2 * BC * AB)) * (180 / Math.PI);
			if (A.y > C.y) {
				return 180 + (180 - calcAngel);
			}
			return calcAngel;

		}

		function calcAngle(x1, x2, y1, y2) {
			var calcAngle = Math.atan2(y2 - y1, x2 - x1);
			/*
			 if (calcAngle < 0)
			 calcAngle = Math.abs(calcAngle);
			 else
			 calcAngle = 360 - calcAngle;*/

			return calcAngle;
		}

		function myMove(e) {

			if (isResizeDrag) {

				if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
					getMouse1(e);
				} else {
					getMouse(e);
				}
				////console.log(mx+"---"+my+"+++"+e.touches[0].pageX);
				var angleMade = calcAngle(center.x, mx, center.y, my);
				////console.log(angleMade);
				//var radius =Math.abs(d/Math.cos(angleMade));
				switch (expectResize) {
				case 0:
					////console.log(mx+"---"+my+"+++"+e.touches[0].pageX);
					vertices[1].x = center.x + (Math.cos(angleMade) * radius);
					vertices[1].y = center.y + (Math.sin(angleMade) * radius);

					////console.log(vertices.x,vertices.y);
					break;
				/*

				 case 1:

				 vertices[1].x = mx;
				 vertices[1].y = my;
				 break;
				 case 2:
				 vertices[2].x = mx;
				 vertices[2].y = my;
				 break;*/

				}
				return;
			}

			if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
				getMouse1(e);
			} else {
				getMouse(e);
			}
			// if there's a selection see if we grabbed one of the selection handles
			if ((mx <= vertices[1].x + half && mx >= vertices[1].x - half) && (my <= vertices[1].y + half && my >= vertices[1].y - half))
				expectResize = 0;
			else
				expectResize = 4;
			switch (expectResize) {
			case 0:
				this.style.cursor = 'pointer';
				//this.style.pointerEvents = "auto";
				break;
			case 1:
				this.style.cursor = 'pointer';
				//this.style.pointerEvents = "none";
				break;
			case 2:
				this.style.cursor = 'pointer';
				//this.style.pointerEvents = "none";
				break;
			default:
				this.style.cursor = 'default';
			}
			return;
		}

		/*
		function myMove1(e) {
		////console.log(1);
		if (isResizeDrag) {
		//console.log(2);
		getMouse1(e);
		var angleMade = calcAngle(vertices[0].x, mx, vertices[0].y, my);
		vertices[1].x = mx;
		vertices[1].y = my;
		vertices[1].x = vertices[0].x + (Math.cos(angleMade) * radius);
		vertices[1].y = vertices[0].y + (Math.sin(angleMade) * radius);

		vertices[2].x = vertices[1].x + (Math.cos(angleMade + (Math.PI / 2)) * 250);
		vertices[2].y = vertices[1].y + (Math.sin(angleMade + (Math.PI / 2)) * 250);

		vertices[3].x = vertices[1].x + (Math.cos(angleMade - (Math.PI / 2)) * 250);
		vertices[3].y = vertices[1].y + (Math.sin(angleMade - (Math.PI / 2)) * 250);
		switch (expectResize) {
		case 0:
		////console.log(mx+"---"+my+"+++"+e.touches[0].pageX);

		break;*/

		/*

		case 1:
		vertices[1].x = mx;
		vertices[1].y = my;
		break;
		case 2:
		vertices[2].x = mx;
		vertices[2].y = my;
		break;
		*/

		/*
		}
		return;
		}

		//getMouse(e);
		// if there's a selection see if we grabbed one of the selection handles
		if ((mx <= vertices[1].x + half && mx >= vertices[1].x - half) && (my <= vertices[1].y + half && my >= vertices[1].y - half))
		expectResize = 0;
		else
		expectResize = 4;
		switch (expectResize) {
		case 0:
		this.style.cursor = 'pointer';
		//this.style.pointerEvents = "auto";
		break;
		case 1:
		this.style.cursor = 'pointer';
		//this.style.pointerEvents = "none";
		break;
		case 2:
		this.style.cursor = 'pointer';
		//this.style.pointerEvents = "none";
		break;
		default:
		this.style.cursor = 'default';
		}
		return;
		}
		*/

		// Happens when the mouse is clicked in the canvas
		function myDown(e) {
			getMouse(e);
			if (expectResize !== -1) {
				this.style.cursor = 'none';
				isResizeDrag = true;
				return;
			}
		}

		function myDown1(e) {
			////console.log("down");
			e.preventDefault();
			getMouse1(e);
			if (expectResize !== -1) {
				this.style.cursor = 'none';
				isResizeDrag = true;
				return;
			}
		}

		function myUp(e) {
			//this.style.cursor = 'default';
			isDrag = false;
			isResizeDrag = false;
			expectResize = -1;
		}

		function getMouse(e) {
			////console.log(e);
			var element = c, offsetX = 0, offsetY = 0;
			if (element.offsetParent) {
				do {
					offsetX += element.offsetLeft;
					offsetY += element.offsetTop;
				} while ((element = element.offsetParent));
			}

			// Add padding and border style widths to offset
			offsetX += stylePaddingLeft;
			offsetY += stylePaddingTop;

			offsetX += styleBorderLeft;
			offsetY += styleBorderTop;

			if (e.pageX - offsetX > 10 && e.pageY - offsetY > 10 && e.pageX - offsetX < 700 && e.pageY - offsetY < 450) {
				mx = e.pageX - offsetX;
				my = e.pageY - offsetY;
			} else {
				myUp(e);
			}

		}

		function getMouse1(e) {
			////console.log("getMouse");
			////console.log(e);
			e.preventDefault();
			var element = c, offsetX = 0, offsetY = 0;
			if (element.offsetParent) {
				do {
					offsetX += element.offsetLeft;
					offsetY += element.offsetTop;
				} while ((element = element.offsetParent));
			}

			// Add padding and border style widths to offset
			offsetX += stylePaddingLeft;
			offsetY += stylePaddingTop;

			offsetX += styleBorderLeft;
			offsetY += styleBorderTop;
			if (e.touches[0].pageX - offsetX > 10 && e.touches[0].pageY - offsetY > 10 && e.touches[0].pageX - offsetX < 700 && e.touches[0].pageY - offsetY < 450) {
				mx = e.touches[0].pageX - offsetX;
				my = e.touches[0].pageY - offsetY;
				////console.log(mx, my);
			}
			if ((mx <= vertices[1].x + 20 && mx >= vertices[1].x - 20) && (my <= vertices[1].y + 20 && my >= vertices[1].y - 20)) {
				expectResize = 0;
				isResizeDrag = true;
			}
		}

	};

	Helper.prototype.destroy = function() {
		mySelf.objActivity.stopAudio("bgSound");
	};

	return Helper;
});
