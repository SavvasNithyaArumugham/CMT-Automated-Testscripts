define('text!components/lifemeter/template/life.html',[],function () { return '';});
