define([
    'player/base/base-activity-model'
], function(BaseActivityModel){
    
    var ActivityModel = BaseActivityModel.extend({
           defaults: {
        		  hotspot_click:0
        }
    });
    
    ActivityModel.prototype.__super__ = BaseActivityModel;
    
    return ActivityModel;
});