/*jslint nomen: true*/
/*globals Backbone,_,console,$,class,device*/

define(['player/screen/screen-helper'], function(ScreenHelper) {'use strict';
	var Screen2Helper;

	Screen2Helper = ScreenHelper.extend({

	});

	Screen2Helper.prototype.init = function() {
		$("#screenHolder").removeClass("screenHolderI").addClass("screenHolderH");
	};
	
	
	Screen2Helper.prototype.destroy = function() {
		
	};

	return Screen2Helper;

});
